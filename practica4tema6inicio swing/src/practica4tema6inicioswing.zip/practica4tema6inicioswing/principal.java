package practica4tema6inicioswing;







import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class principal extends JFrame  {

	

	

		
	public static void main(String[] args) {
		secventana aPrimera=new secventana();
		primeraVentana aVentana=new primeraVentana();
		
		
		
		  
		

	}

}
