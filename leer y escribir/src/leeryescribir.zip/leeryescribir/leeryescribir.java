package leeryescribir;
import java.io.*;
public class leeryescribir {

	public static void main(String[] args) {
	FileWriter javapepe1 =null;
	
	String javapepe ="C:\\Users\\jorge\\Desktop\\javapepe.txt";
	
	try {
		javapepe1=new FileWriter(javapepe);
		
		String linea="esto es una prueba de javapepe";
		
		for (int i = 0; i < linea.length(); i++) {
			javapepe1.write(linea.charAt(i));
		}
		javapepe1.close();
		FileReader javapepe2=null;
		javapepe2=new FileReader(javapepe);
		int caract=javapepe2.read();
		while (caract != -1) {
			System.out.print((char)caract);
			caract=javapepe2.read();
			
		}
		javapepe2.close();
		
	}catch (Exception e) {
		System.out.println(e.getMessage());
	}

	}

}
