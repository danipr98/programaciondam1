package leeryescribir;

public class tema6practica3 {

	public static void main(String[] args) {
		alumno a1 =new alumno("dani","paz");
		

		objetoalumno.obj1(a1);
		objetoalumno.array1();
		objetoalumno.file();

	}

}
